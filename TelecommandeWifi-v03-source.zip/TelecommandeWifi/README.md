# Télécommande Wi-Fi — prototype v0.3

## Nouveautés
- Découverte mDNS/Bonjour (Apple TV Companion, MediaRemoteTV, AirPlay, Google Cast, Android TV Remote, Roku, Kodi).
- Découverte SSDP Roku conservée.
- Les appareils détectés apparaissent même sans pilote de contrôle disponible.
- Télécommande à boutons arrondis, commandes groupées et distinction explicite des pilotes indisponibles.

## Limitations essentielles
- **Apple TV est détectable, mais PAS encore pilotable** : Companion nécessite un appairage et une session chiffrée.
- Samsung, LG, Android TV, Sony, VIDAA : détection partielle selon les annonces réseau, contrôle non implémenté.
- Roku ECP et Kodi JSON-RPC : commandes existantes, non validées sur appareil réel.
- La liste n'est pas l'inventaire de tous les clients Wi-Fi de la box : seuls les appareils qui annoncent des services mDNS/SSDP apparaissent.
- Aucune compilation ni validation sur appareil réel effectuée dans cet environnement.

## Compilation
Décompresser le projet dans GitHub, puis exécuter `.github/workflows/build.yml` via GitHub Actions. Récupérer l'APK debug dans Artifacts si le build réussit.
