package com.example.telecommandewifi

import android.app.Activity
import android.os.Bundle
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.*
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.Executors

/** Local-only controller. Discovery does not imply remote-control authorization. */
class MainActivity : Activity() {
    data class Device(val name: String, val host: String, val type: String)
    private val bg = Executors.newSingleThreadExecutor()
    private val devices = mutableListOf<Device>()
    private val nearby = linkedMapOf<String,Device>()
    private val discoveryListeners = mutableListOf<NsdManager.DiscoveryListener>()
    private val mainHandler = Handler(Looper.getMainLooper())
    private var active: Device? = null
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private lateinit var saved: LinearLayout
    private lateinit var controls: LinearLayout
    private lateinit var discovered: LinearLayout
    private lateinit var ip: EditText
    private lateinit var type: Spinner
    private val prefs by lazy { getSharedPreferences("devices", MODE_PRIVATE) }
    private val ink = Color.rgb(237,242,255)
    private val muted = Color.rgb(170,184,207)
    private val background = Color.rgb(12,18,31)
    private val panel = Color.rgb(27,37,56)
    private val accent = Color.rgb(79,145,244)
    private val gold = Color.rgb(123, 204, 218)
    private val types = listOf("Roku (ECP)", "Kodi (JSON-RPC)", "Samsung (à venir)", "LG webOS (à venir)", "Android TV (à venir)", "Apple TV (à venir)", "Sony Bravia (à venir)", "Sharp / VIDAA (à venir)")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = background; window.navigationBarColor = background
        val scroll = ScrollView(this).apply { setBackgroundColor(background); fillViewport = true }
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(24), dp(18), dp(24)) }
        scroll.addView(root); setContentView(scroll)
        heading("Télécommande Wi-Fi", 26)
        label("Contrôle local • Sans compte • Sans cloud")
        status = TextView(this).apply { textSize = 14f; setTextColor(muted); setPadding(0, dp(12), 0, dp(12)) }
        root.addView(status)
        heading("Appareils à proximité", 19)
        discovered = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; root.addView(discovered)
        heading("Mes appareils", 19)
        saved = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; root.addView(saved)
        button(root, "Rechercher sur le Wi-Fi", accent) { discover() }
        heading("Ajouter manuellement", 19)
        ip = EditText(this).apply { hint = "Adresse IP, ex. 192.168.1.20"; setSingleLine(true); setTextColor(ink); setHintTextColor(muted); inputType = 3 }
        root.addView(ip)
        type = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, types) }
        root.addView(type)
        button(root, "Ajouter et tester", panel) {
            val host = ip.text.toString().trim()
            if (!validIp(host)) { message("Adresse IPv4 invalide"); return@button }
            val kind = types[type.selectedItemPosition]
            if (!supported(kind)) { message("Pilote $kind non disponible dans cette version. Aucun appairage simulé."); return@button }
            val d = Device("${kind.substringBefore(" (")} • $host", host, kind)
            save(d); select(d); test(d)
        }
        controls = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; root.addView(controls)
        button(root, "Diagnostic Wi-Fi", panel) {
            message(if (onWifi()) "Wi-Fi actif. Les appareils doivent être sur le même réseau, sans isolation des clients." else "Wi-Fi non détecté : connecte le téléphone au même réseau que la télévision.")
        }
        label("Compatibilité réelle de cette version : Roku ECP et Kodi JSON-RPC. Les autres marques, dont Apple TV, nécessitent un pilote et un appairage spécifiques. La détection seule ne permet pas leur contrôle.")
        restore(); renderSaved(); renderNearby(); renderRemote(); message(if (onWifi()) "Wi-Fi connecté. Lance une recherche ou choisis un appareil." else "Connecte ton téléphone au Wi-Fi pour découvrir les appareils.")
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun heading(t: String, size: Int) { root.addView(TextView(this).apply { text=t; textSize=size.toFloat(); setTypeface(null, Typeface.BOLD); setTextColor(ink); setPadding(0,dp(14),0,dp(8)) }) }
    private fun label(t: String) { root.addView(TextView(this).apply { text=t; textSize=13f; setTextColor(muted); setPadding(0,dp(3),0,dp(12)) }) }
    private fun button(parent: LinearLayout, title: String, color: Int = panel, action: () -> Unit): Button {
        val b = Button(this).apply { text=title; isAllCaps=false; textSize=14f; setTextColor(ink); setBackgroundTintList(android.content.res.ColorStateList.valueOf(color)); minHeight=dp(48); setOnClickListener { action() } }
        parent.addView(b, LinearLayout.LayoutParams(-1, dp(54))); return b
    }
    private fun row(vararg entries: Pair<String,String>) {
        val r = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER }
        entries.forEach { (label,key) ->
            val b=Button(this).apply { text=label; isAllCaps=false; textSize=17f; setTypeface(null,Typeface.BOLD); setTextColor(ink); background=rounded(panel,20); isEnabled=key.isNotEmpty() && supported(d.type); setOnClickListener { vibrate(); send(key) } }
            r.addView(b, LinearLayout.LayoutParams(0,dp(58),1f))
        }; controls.addView(r)
    }
    private fun rounded(color:Int, radius:Int):GradientDrawable = GradientDrawable().apply { setColor(color); cornerRadius=dp(radius).toFloat(); setStroke(dp(1),Color.rgb(50,65,84)) }
    private fun renderRemote() {
        controls.removeAllViews(); val d=active ?: return
        val title=TextView(this).apply { text="◉  ${d.name}"; textSize=21f; setTypeface(null,Typeface.BOLD); setTextColor(ink); setPadding(0,dp(18),0,dp(10)) }; controls.addView(title)
        row("⏻" to "Power", "⌂" to "Home", "↶" to "Back")
        row("" to "", "▲" to "Up", "" to "")
        row("◀" to "Left", "OK" to "Select", "▶" to "Right")
        row("" to "", "▼" to "Down", "" to "")
        row("VOL +" to "VolumeUp", "◌" to "VolumeMute", "VOL −" to "VolumeDown")
        row("CH +" to "ChannelUp", "CH −" to "ChannelDown")
        row("⏮" to "Rev", "⏯" to "Play", "⏭" to "Fwd")
        row("1" to "Lit_1", "2" to "Lit_2", "3" to "Lit_3")
        row("4" to "Lit_4", "5" to "Lit_5", "6" to "Lit_6")
        row("7" to "Lit_7", "8" to "Lit_8", "9" to "Lit_9")
        row("Menu" to "Info", "0" to "Lit_0", "Entrée" to "Enter")
        button(controls,"Tester la connexion",panel) { test(d) }
        button(controls,"Supprimer cet appareil",panel) { devices.remove(d); active=devices.firstOrNull(); persist(); renderSaved(); renderRemote(); message("Appareil supprimé") }
    }
    private fun supported(t:String)=t.startsWith("Roku") || t.startsWith("Kodi")
    private fun select(d:Device) { active=d; renderSaved(); renderRemote(); message("${d.name} sélectionné. Vérifie la connexion avant d'envoyer des commandes.") }
    private fun renderSaved() {
        saved.removeAllViews()
        if (devices.isEmpty()) { val t=TextView(this).apply { text="Aucun appareil enregistré"; setTextColor(muted) }; saved.addView(t) }
        devices.forEach { d -> button(saved, (if (d==active) "● " else "○ ")+d.name,if(d==active) accent else panel) { select(d) } }
    }
    private fun validIp(s:String):Boolean { val parts=s.split('.'); return parts.size==4 && parts.all { it.isNotEmpty() && it.length<=3 && it.all(Char::isDigit) && (it.toIntOrNull() ?: 256) in 0..255 } }
    private fun save(d:Device) { if (devices.none { it.host==d.host && it.type==d.type }) devices.add(d); persist(); renderSaved() }
    private fun persist() { val a=JSONArray(); devices.forEach { a.put(JSONObject().put("name",it.name).put("host",it.host).put("type",it.type)) }; prefs.edit().putString("saved",a.toString()).apply() }
    private fun restore() { try { val a=JSONArray(prefs.getString("saved","[]")); for(i in 0 until a.length()) { val o=a.getJSONObject(i); val d=Device(o.getString("name"),o.getString("host"),o.getString("type")); if(validIp(d.host)&&supported(d.type)) devices.add(d) }; active=devices.firstOrNull() } catch (_:Exception) {} }
    private fun message(s:String) { runOnUiThread { status.text=s } }
    private fun onWifi():Boolean { val cm=getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager; val n=cm.activeNetwork ?: return false; return cm.getNetworkCapabilities(n)?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)==true }
    private fun vibrate() { try { val v=getSystemService(VIBRATOR_SERVICE) as Vibrator; v.vibrate(VibrationEffect.createOneShot(18,VibrationEffect.DEFAULT_AMPLITUDE)) } catch (_:Exception) {} }
    private fun test(d:Device) { message("Test de ${d.host}…"); bg.execute { try { if(d.type.startsWith("Roku")) { val r=request("http://${d.host}:8060/query/device-info","GET"); if(!r.contains("<device-info")) error("Réponse Roku inattendue") } else { val r=kodi(d,"JSONRPC.Ping",null); if(!r.contains("pong",true)) error("Kodi n'a pas répondu") }; message("✓ ${d.name} répond sur le réseau") } catch(e:Exception) { message("Connexion impossible (${e.javaClass.simpleName}). Vérifie l'IP, le protocole et les réglages réseau de la TV.") } } }
    private fun send(key:String) {
        val d=active ?: return
        if(!onWifi()) { message("Wi-Fi désactivé ou indisponible"); return }
        message("Envoi : $key…")
        bg.execute { try {
            if(d.type.startsWith("Roku")) { request("http://${d.host}:8060/keypress/${URLEncoder.encode(key,"UTF-8")}","POST") }
            else { val mapped=when(key) {
                "Up"->"Input.Up"; "Down"->"Input.Down"; "Left"->"Input.Left"; "Right"->"Input.Right"; "Select","Enter"->"Input.Select"; "Back"->"Input.Back"; "Home"->"Input.Home"; "Info"->"Input.ContextMenu"
                "VolumeUp"->"Application.SetVolume"; "VolumeDown"->"Application.SetVolume"; "VolumeMute"->"Application.SetMute"
                "Play"->"Player.PlayPause"; "Rev"->"Player.GoTo"; "Fwd"->"Player.GoTo"
                else->null
            } ?: error("Commande non disponible sur Kodi")
                val params:JSONObject?=when(key) { "VolumeUp"->JSONObject().put("volume","increment"); "VolumeDown"->JSONObject().put("volume","decrement"); "VolumeMute"->JSONObject().put("mute","toggle"); "Play"->JSONObject().put("playerid",1); "Rev","Fwd"->JSONObject().put("playerid",1).put("to",if(key=="Rev") "previous" else "next"); else->null }
                val result=kodi(d,mapped,params); if(JSONObject(result).has("error")) error(JSONObject(result).getJSONObject("error").optString("message","Kodi error"))
            }
            message("✓ Commande $key transmise à ${d.name}")
        } catch(e:Exception) { message("Commande $key : ${e.message ?: "échec réseau"}") } }
    }
    private fun kodi(d:Device,method:String,params:JSONObject?):String {
        val url=URL("http://${d.host}:8080/jsonrpc"); val conn=url.openConnection() as HttpURLConnection
        try { conn.requestMethod="POST"; conn.connectTimeout=2200; conn.readTimeout=2200; conn.doOutput=true; conn.setRequestProperty("Content-Type","application/json")
            val obj=JSONObject().put("jsonrpc","2.0").put("id",1).put("method",method); if(params!=null) obj.put("params",params)
            conn.outputStream.use { it.write(obj.toString().toByteArray(Charsets.UTF_8)) }
            if(conn.responseCode !in 200..299) error("HTTP ${conn.responseCode}; active le contrôle HTTP dans Kodi")
            return conn.inputStream.bufferedReader().use { it.readText() }
        } finally { conn.disconnect() }
    }
    private fun request(endpoint:String,method:String):String {
        val conn=URL(endpoint).openConnection() as HttpURLConnection
        try { conn.requestMethod=method; conn.connectTimeout=2200; conn.readTimeout=2200
            if(conn.responseCode !in 200..299) error("HTTP ${conn.responseCode}")
            return conn.inputStream.bufferedReader().use { it.readText() }
        } finally { conn.disconnect() }
    }
    private fun renderNearby() {
        discovered.removeAllViews()
        if(nearby.isEmpty()) {
            discovered.addView(TextView(this).apply { text="Aucun appareil détecté pour le moment. Lance une recherche."; textSize=13f; setTextColor(muted); setPadding(0,dp(6),0,dp(8)) })
        }
        nearby.values.forEach { d ->
            button(discovered,"▣  ${d.name}  ·  ${d.host}  ·  ${if(supported(d.type)) "Contrôlable" else "Appairage non disponible"}",panel) {
                if(supported(d.type)) { save(d); select(d); test(d) }
                else message("${d.name} détecté à ${d.host}. Son pilote de contrôle et son appairage ne sont pas encore implémentés.")
            }
        }
    }
    private fun registerNearby(d:Device) {
        runOnUiThread { nearby[d.host+":"+d.type]=d; renderNearby() }
    }
    private fun stopMdns() {
        val nsd=getSystemService(Context.NSD_SERVICE) as NsdManager
        discoveryListeners.toList().forEach { try { nsd.stopServiceDiscovery(it) } catch (_:Exception) {} }
        discoveryListeners.clear()
    }
    private fun discoverMdns() {
        stopMdns()
        val nsd=getSystemService(Context.NSD_SERVICE) as NsdManager
        val services= listOf(
            "_companion-link._tcp." to "Apple TV (Companion)",
            "_mediaremotetv._tcp." to "Apple TV (Remote)",
            "_airplay._tcp." to "Apple TV / AirPlay",
            "_googlecast._tcp." to "Google Cast",
            "_androidtvremote2._tcp." to "Android TV",
            "_roku-ecp._tcp." to "Roku (ECP)",
            "_xbmc-jsonrpc-h._tcp." to "Kodi (JSON-RPC)"
        )
        services.forEach { (serviceType,kind) ->
            val listener=object:NsdManager.DiscoveryListener {
                override fun onDiscoveryStarted(t:String) {}
                override fun onDiscoveryStopped(t:String) {}
                override fun onStartDiscoveryFailed(t:String,errorCode:Int) { try { nsd.stopServiceDiscovery(this) } catch (_:Exception) {} }
                override fun onStopDiscoveryFailed(t:String,errorCode:Int) {}
                override fun onServiceFound(info:NsdServiceInfo) {
                    @Suppress("DEPRECATION")
                    nsd.resolveService(info,object:NsdManager.ResolveListener {
                        override fun onResolveFailed(i:NsdServiceInfo,errorCode:Int) {}
                        override fun onServiceResolved(i:NsdServiceInfo) {
                            val host=i.host?.hostAddress ?: return
                            if(!validIp(host)) return
                            val deviceType=if(kind=="Roku (ECP)") kind else if(kind=="Kodi (JSON-RPC)") kind else "$kind (détection)"
                            registerNearby(Device(i.serviceName.ifBlank { kind },host,deviceType))
                        }
                    })
                }
                override fun onServiceLost(info:NsdServiceInfo) {}
            }
            try { nsd.discoverServices(serviceType,NsdManager.PROTOCOL_DNS_SD,listener); discoveryListeners.add(listener) } catch (_:Exception) {}
        }
        mainHandler.postDelayed({ stopMdns(); message("Recherche terminée : ${nearby.size} appareil(s) détecté(s). Certains équipements Wi-Fi ne publient aucun service découvrable.") },10000)
    }
    private fun discover() {
        if(!onWifi()) { message("Connecte ton Galaxy au Wi-Fi avant la recherche"); return }
        nearby.clear(); renderNearby(); discoverMdns(); message("Recherche mDNS + SSDP en cours (10 secondes)…")
        bg.execute {
            val found=mutableSetOf<String>(); var count=0
            try {
                val cm=getSystemService(Context.WIFI_SERVICE) as android.net.wifi.WifiManager
                val lock=cm.createMulticastLock("remote-ssdp"); lock.setReferenceCounted(false); lock.acquire()
                try {
                    MulticastSocket().use { socket ->
                        socket.soTimeout=600; socket.timeToLive=2
                        val query="M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nMAN: \"ssdp:discover\"\r\nMX: 2\r\nST: ssdp:all\r\n\r\n".toByteArray(Charsets.UTF_8)
                        socket.send(DatagramPacket(query,query.size,InetAddress.getByName("239.255.255.250"),1900))
                        val until=System.currentTimeMillis()+6000
                        while(System.currentTimeMillis()<until) {
                            val buf=ByteArray(8192); val packet=DatagramPacket(buf,buf.size)
                            try { socket.receive(packet) } catch (_:SocketTimeoutException) { continue }
                            val host=packet.address.hostAddress ?: continue
                            val text=String(packet.data,0,packet.length,Charsets.UTF_8)
                            if(!validIp(host)||!found.add(host)) continue
                            // Only register a Roku after verifying its ECP endpoint.
                            try { val xml=request("http://$host:8060/query/device-info","GET")
                                if(xml.contains("<device-info")) { val d=Device("Roku • $host",host,"Roku (ECP)"); registerNearby(d); count++ }
                            } catch (_:Exception) {}
                            // Other SSDP devices may be TVs but cannot be controlled by Roku commands.
                            if(text.contains("kodi",true)) { /* Kodi HTTP discovery requires separate verification. */ }
                        }
                    }
                } finally { if(lock.isHeld) lock.release() }
                message("Recherche SSDP terminée : $count Roku détecté(s). Recherche mDNS en cours…")
            } catch(e:Exception) { message("Recherche impossible : ${e.message ?: "réseau bloqué"}. Essaie l'ajout manuel.") }
        }
    }
    override fun onDestroy() { stopMdns(); mainHandler.removeCallbacksAndMessages(null); bg.shutdownNow(); super.onDestroy() }
}
