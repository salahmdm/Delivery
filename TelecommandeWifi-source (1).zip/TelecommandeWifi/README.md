# Télécommande Wi-Fi (Android)

Application Android (Kotlin, Jetpack Compose) qui contrôle vos appareils depuis le
même réseau Wi-Fi, sans compte ni serveur.

## Appareils pris en charge
- Roku (ECP, port 8060)
- Samsung Smart TV Tizen (WebSocket, port 8002 — accepter la demande sur la TV)
- Kodi (JSON-RPC, port 8080 — activer le contrôle HTTP dans Kodi)

## Navigation
- Flèche retour en haut à gauche sur toutes les pages (retour à la page principale).
- Le bouton retour du téléphone ramène aussi à la page principale.
- Barre du bas toujours visible : Accueil, Télécommande, Appareils, Réglages.
- Mode démo : la télécommande est consultable même sans appareil connecté.

## Compiler
- Android Studio : ouvrir le dossier, puis Run.
- Ligne de commande : `gradle :app:assembleDebug`
  (Gradle 8.13, Java 17, Android SDK 35). L'APK est dans `app/build/outputs/apk/debug/`.

## Structure
- `data/` modèles et stockage local
- `net/` découverte SSDP et pilotes (un par marque)
- `ui/` écrans Compose et ViewModel
