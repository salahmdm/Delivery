package com.telecommande.wifi.data

enum class DeviceType(val label: String) {
    ROKU("Roku"),
    SAMSUNG("Samsung (Tizen)"),
    KODI("Kodi"),
    UNKNOWN("Non pris en charge")
}

data class Device(
    val id: String,
    val name: String,
    val ip: String,
    val type: DeviceType,
    val token: String = ""
)

enum class RemoteKey {
    POWER, UP, DOWN, LEFT, RIGHT, OK, BACK, HOME, MENU,
    VOL_UP, VOL_DOWN, MUTE, CH_UP, CH_DOWN,
    PLAY_PAUSE, REWIND, FORWARD, STOP,
    NUM_0, NUM_1, NUM_2, NUM_3, NUM_4, NUM_5, NUM_6, NUM_7, NUM_8, NUM_9
}

fun RemoteKey.digit(): Int? =
    if (name.startsWith("NUM_")) name.removePrefix("NUM_").toIntOrNull() else null
