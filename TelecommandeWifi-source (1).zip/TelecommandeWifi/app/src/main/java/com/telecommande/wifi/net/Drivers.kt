package com.telecommande.wifi.net

import android.util.Base64
import com.telecommande.wifi.data.RemoteKey
import com.telecommande.wifi.data.digit
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.security.SecureRandom
import java.security.cert.X509Certificate
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

interface RemoteDriver {
    suspend fun send(key: RemoteKey): Result<Unit>
    fun close() {}
}

internal fun httpPost(url: String, body: String?, contentType: String?): Int {
    val c = URL(url).openConnection() as HttpURLConnection
    try {
        c.requestMethod = "POST"
        c.connectTimeout = 3000
        c.readTimeout = 3000
        c.doOutput = true
        if (contentType != null) c.setRequestProperty("Content-Type", contentType)
        val bytes = (body ?: "").toByteArray()
        c.setFixedLengthStreamingMode(bytes.size)
        c.outputStream.use { it.write(bytes) }
        val code = c.responseCode
        try {
            c.inputStream.close()
        } catch (e: Exception) {
            // on ignore : seul le code de réponse nous intéresse
        }
        return code
    } finally {
        c.disconnect()
    }
}

class UnsupportedDriver : RemoteDriver {
    override suspend fun send(key: RemoteKey): Result<Unit> =
        Result.failure<Unit>(IOException("Ce type d'appareil n'est pas encore pris en charge."))
}

/** Roku : protocole ECP (HTTP, port 8060). Aucun appairage nécessaire. */
class RokuDriver(private val ip: String) : RemoteDriver {

    private fun keyName(key: RemoteKey): String? = when (key) {
        RemoteKey.POWER -> "Power"
        RemoteKey.UP -> "Up"
        RemoteKey.DOWN -> "Down"
        RemoteKey.LEFT -> "Left"
        RemoteKey.RIGHT -> "Right"
        RemoteKey.OK -> "Select"
        RemoteKey.BACK -> "Back"
        RemoteKey.HOME -> "Home"
        RemoteKey.MENU -> "Info"
        RemoteKey.VOL_UP -> "VolumeUp"
        RemoteKey.VOL_DOWN -> "VolumeDown"
        RemoteKey.MUTE -> "VolumeMute"
        RemoteKey.CH_UP -> "ChannelUp"
        RemoteKey.CH_DOWN -> "ChannelDown"
        RemoteKey.PLAY_PAUSE -> "Play"
        RemoteKey.REWIND -> "Rev"
        RemoteKey.FORWARD -> "Fwd"
        RemoteKey.STOP -> null
        else -> key.digit()?.let { "Lit_$it" }
    }

    override suspend fun send(key: RemoteKey): Result<Unit> = withContext(Dispatchers.IO) {
        val name = keyName(key)
            ?: return@withContext Result.failure<Unit>(IOException("Touche non disponible sur Roku."))
        runCatching {
            val code = httpPost("http://" + ip + ":8060/keypress/" + name, null, null)
            if (code !in 200..299) throw IOException("Le Roku a répondu : HTTP " + code)
            Unit
        }
    }
}

/** Kodi : JSON-RPC (HTTP, port 8080). Activer « Autoriser le contrôle à distance via HTTP » dans Kodi. */
class KodiDriver(private val ip: String, private val port: Int = 8080) : RemoteDriver {

    private fun payload(key: RemoteKey): String? {
        val method: String? = when (key) {
            RemoteKey.UP -> "Input.Up"
            RemoteKey.DOWN -> "Input.Down"
            RemoteKey.LEFT -> "Input.Left"
            RemoteKey.RIGHT -> "Input.Right"
            RemoteKey.OK -> "Input.Select"
            RemoteKey.BACK -> "Input.Back"
            RemoteKey.HOME -> "Input.Home"
            RemoteKey.MENU -> "Input.ContextMenu"
            else -> null
        }
        if (method != null) {
            return "{\"jsonrpc\":\"2.0\",\"method\":\"" + method + "\",\"id\":1}"
        }
        val action: String? = when (key) {
            RemoteKey.VOL_UP -> "volumeup"
            RemoteKey.VOL_DOWN -> "volumedown"
            RemoteKey.MUTE -> "mute"
            RemoteKey.PLAY_PAUSE -> "playpause"
            RemoteKey.STOP -> "stop"
            RemoteKey.REWIND -> "rewind"
            RemoteKey.FORWARD -> "fastforward"
            RemoteKey.CH_UP -> "pageup"
            RemoteKey.CH_DOWN -> "pagedown"
            RemoteKey.POWER -> "shutdownmenu"
            else -> key.digit()?.let { "number" + it }
        }
        if (action == null) return null
        return "{\"jsonrpc\":\"2.0\",\"method\":\"Input.ExecuteAction\"," +
            "\"params\":{\"action\":\"" + action + "\"},\"id\":1}"
    }

    override suspend fun send(key: RemoteKey): Result<Unit> = withContext(Dispatchers.IO) {
        val body = payload(key)
            ?: return@withContext Result.failure<Unit>(IOException("Touche non disponible sur Kodi."))
        runCatching {
            val code = httpPost(
                "http://" + ip + ":" + port + "/jsonrpc",
                body,
                "application/json"
            )
            if (code !in 200..299) throw IOException("Kodi a répondu : HTTP " + code)
            Unit
        }
    }
}

/**
 * Samsung Smart TV (Tizen) : WebSocket sécurisé, port 8002.
 * Au premier appairage, la TV affiche une demande d'autorisation à accepter.
 */
class SamsungDriver(
    private val ip: String,
    private var token: String,
    private val onToken: (String) -> Unit
) : RemoteDriver {

    private val client: OkHttpClient by lazy {
        val trustAll = object : X509TrustManager {
            override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) {}
            override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) {}
            override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
        }
        val ctx = SSLContext.getInstance("TLS")
        ctx.init(null, arrayOf<TrustManager>(trustAll), SecureRandom())
        OkHttpClient.Builder()
            .sslSocketFactory(ctx.socketFactory, trustAll)
            .hostnameVerifier { _, _ -> true }
            .connectTimeout(5, TimeUnit.SECONDS)
            .readTimeout(0, TimeUnit.MILLISECONDS)
            .pingInterval(20, TimeUnit.SECONDS)
            .build()
    }

    @Volatile
    private var socket: WebSocket? = null

    @Volatile
    private var connected: CompletableDeferred<Boolean>? = null

    private fun keyCode(key: RemoteKey): String? = when (key) {
        RemoteKey.POWER -> "KEY_POWER"
        RemoteKey.UP -> "KEY_UP"
        RemoteKey.DOWN -> "KEY_DOWN"
        RemoteKey.LEFT -> "KEY_LEFT"
        RemoteKey.RIGHT -> "KEY_RIGHT"
        RemoteKey.OK -> "KEY_ENTER"
        RemoteKey.BACK -> "KEY_RETURN"
        RemoteKey.HOME -> "KEY_HOME"
        RemoteKey.MENU -> "KEY_MENU"
        RemoteKey.VOL_UP -> "KEY_VOLUP"
        RemoteKey.VOL_DOWN -> "KEY_VOLDOWN"
        RemoteKey.MUTE -> "KEY_MUTE"
        RemoteKey.CH_UP -> "KEY_CHUP"
        RemoteKey.CH_DOWN -> "KEY_CHDOWN"
        RemoteKey.PLAY_PAUSE -> "KEY_PLAY"
        RemoteKey.REWIND -> "KEY_REWIND"
        RemoteKey.FORWARD -> "KEY_FF"
        RemoteKey.STOP -> "KEY_STOP"
        else -> key.digit()?.let { "KEY_" + it }
    }

    private suspend fun ensureConnected() {
        val existing = connected
        if (socket != null && existing != null && existing.isCompleted && existing.await()) return

        close()
        val deferred = CompletableDeferred<Boolean>()
        connected = deferred

        val name = Base64.encodeToString("TelecommandeWifi".toByteArray(), Base64.NO_WRAP)
        val tokenPart = if (token.isNotEmpty()) "&token=" + token else ""
        val url = "wss://" + ip + ":8002/api/v2/channels/samsung.remote.control?name=" + name + tokenPart
        val request = Request.Builder().url(url).build()

        socket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onMessage(webSocket: WebSocket, text: String) {
                try {
                    val o = JSONObject(text)
                    if (o.optString("event") == "ms.channel.connect") {
                        val newToken = o.optJSONObject("data")?.optString("token") ?: ""
                        if (newToken.isNotEmpty() && newToken != token) {
                            token = newToken
                            onToken(newToken)
                        }
                        deferred.complete(true)
                    }
                } catch (e: Exception) {
                    // message ignoré
                }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                deferred.complete(false)
                socket = null
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                deferred.complete(false)
                socket = null
            }
        })

        val ok = withTimeoutOrNull(20_000L) { deferred.await() } ?: false
        if (!ok) {
            close()
            throw IOException("Connexion à la TV Samsung impossible. Acceptez la demande affichée sur la TV.")
        }
    }

    override suspend fun send(key: RemoteKey): Result<Unit> = withContext(Dispatchers.IO) {
        val code = keyCode(key)
            ?: return@withContext Result.failure<Unit>(IOException("Touche non disponible sur Samsung."))
        runCatching {
            ensureConnected()
            val params = JSONObject()
                .put("Cmd", "Click")
                .put("DataOfCmd", code)
                .put("Option", "false")
                .put("TypeOfRemote", "SendRemoteKey")
            val payload = JSONObject()
                .put("method", "ms.remote.control")
                .put("params", params)
            val sent = socket?.send(payload.toString()) ?: false
            if (!sent) {
                close()
                throw IOException("Envoi impossible vers la TV Samsung.")
            }
            Unit
        }
    }

    override fun close() {
        try {
            socket?.close(1000, "bye")
        } catch (e: Exception) {
            // ignoré
        }
        socket = null
        connected = null
    }
}
