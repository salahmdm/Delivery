package com.telecommande.wifi.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import kotlinx.coroutines.launch

object Routes {
    const val HOME = "home"
    const val REMOTE = "remote"
    const val DEVICES = "devices"
    const val SETTINGS = "settings"
}

private data class Tab(val route: String, val label: String, val icon: ImageVector)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppRoot(vm: AppViewModel = viewModel()) {
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route ?: Routes.HOME
    val snackbar = remember { SnackbarHostState() }

    val tabs = listOf(
        Tab(Routes.HOME, "Accueil", Icons.Filled.Home),
        Tab(Routes.REMOTE, "Télécommande", Icons.Filled.PlayArrow),
        Tab(Routes.DEVICES, "Appareils", Icons.Filled.Search),
        Tab(Routes.SETTINGS, "Réglages", Icons.Filled.Settings)
    )

    fun go(target: String) {
        nav.navigate(target) {
            popUpTo(Routes.HOME) { inclusive = false }
            launchSingleTop = true
        }
    }

    LaunchedEffect(Unit) {
        vm.messages.collect { msg ->
            snackbar.currentSnackbarData?.dismiss()
            launch { snackbar.showSnackbar(msg) }
        }
    }

    // Le bouton retour du téléphone ramène toujours à la page principale.
    BackHandler(enabled = route != Routes.HOME) { go(Routes.HOME) }

    val title = when (route) {
        Routes.REMOTE -> "Télécommande"
        Routes.DEVICES -> "Connexion des appareils"
        Routes.SETTINGS -> "Réglages"
        else -> "Télécommande Wi-Fi"
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title) },
                navigationIcon = {
                    if (route != Routes.HOME) {
                        IconButton(onClick = { go(Routes.HOME) }) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Retour à la page principale"
                            )
                        }
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                tabs.forEach { tab ->
                    NavigationBarItem(
                        selected = route == tab.route,
                        onClick = { go(tab.route) },
                        icon = { Icon(tab.icon, contentDescription = tab.label) },
                        label = { Text(tab.label, maxLines = 1) }
                    )
                }
            }
        },
        snackbarHost = { SnackbarHost(snackbar) }
    ) { inner ->
        NavHost(
            navController = nav,
            startDestination = Routes.HOME,
            modifier = Modifier.padding(inner)
        ) {
            composable(Routes.HOME) {
                HomeScreen(
                    vm = vm,
                    onOpenRemote = { go(Routes.REMOTE) },
                    onOpenDevices = { go(Routes.DEVICES) }
                )
            }
            composable(Routes.REMOTE) {
                RemoteScreen(vm = vm)
            }
            composable(Routes.DEVICES) {
                DevicesScreen(vm = vm, onBackHome = { go(Routes.HOME) })
            }
            composable(Routes.SETTINGS) {
                SettingsScreen(vm = vm)
            }
        }
    }
}
