package com.telecommande.wifi.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.telecommande.wifi.data.Device
import com.telecommande.wifi.data.DeviceType
import com.telecommande.wifi.data.RemoteKey
import com.telecommande.wifi.net.Found

// ---------------------------------------------------------------------------
// Accueil
// ---------------------------------------------------------------------------

@Composable
fun HomeScreen(vm: AppViewModel, onOpenRemote: () -> Unit, onOpenDevices: () -> Unit) {
    val devices by vm.devices.collectAsStateWithLifecycle()
    val selectedId by vm.selectedId.collectAsStateWithLifecycle()
    val activeId = if (devices.any { it.id == selectedId }) selectedId else devices.firstOrNull()?.id

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Column {
                Text("Ma télécommande", style = MaterialTheme.typography.headlineMedium)
                Spacer(Modifier.height(4.dp))
                Text(
                    "Pilotez vos appareils connectés au même réseau Wi-Fi que ce téléphone.",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }

        if (devices.isEmpty()) {
            item {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text("Aucun appareil pour l'instant", style = MaterialTheme.typography.titleMedium)
                        Text(
                            "Vous pouvez déjà parcourir toute l'application. " +
                                "Quand vous le souhaitez, ajoutez un appareil depuis l'onglet « Appareils ».",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Button(onClick = onOpenDevices, modifier = Modifier.fillMaxWidth()) {
                            Text("Rechercher mes appareils")
                        }
                        OutlinedButton(onClick = onOpenRemote, modifier = Modifier.fillMaxWidth()) {
                            Text("Voir la télécommande (mode démo)")
                        }
                    }
                }
            }
        } else {
            items(devices, key = { it.id }) { d ->
                DeviceCard(
                    device = d,
                    active = d.id == activeId,
                    onClick = {
                        vm.selectDevice(d.id)
                        onOpenRemote()
                    },
                    onDelete = { vm.removeDevice(d.id) }
                )
            }
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = onOpenRemote, modifier = Modifier.fillMaxWidth()) {
                        Text("Ouvrir la télécommande")
                    }
                    OutlinedButton(onClick = onOpenDevices, modifier = Modifier.fillMaxWidth()) {
                        Text("Rechercher / ajouter un appareil")
                    }
                }
            }
        }
    }
}

@Composable
private fun DeviceCard(device: Device, active: Boolean, onClick: () -> Unit, onDelete: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth().clickable { onClick() }) {
        Row(
            modifier = Modifier.padding(start = 16.dp, top = 8.dp, bottom = 8.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(device.name, style = MaterialTheme.typography.titleMedium)
                Text(
                    device.type.label + " • " + device.ip,
                    style = MaterialTheme.typography.bodySmall
                )
                if (active) {
                    Text(
                        "Appareil actif",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Filled.Delete, contentDescription = "Supprimer l'appareil")
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Télécommande
// ---------------------------------------------------------------------------

@Composable
private fun RBtn(label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    FilledTonalButton(
        onClick = onClick,
        modifier = modifier,
        contentPadding = PaddingValues(horizontal = 4.dp)
    ) {
        Text(label, maxLines = 1)
    }
}

@Composable
fun RemoteScreen(vm: AppViewModel) {
    val devices by vm.devices.collectAsStateWithLifecycle()
    val selectedId by vm.selectedId.collectAsStateWithLifecycle()
    val haptics by vm.haptics.collectAsStateWithLifecycle()
    val haptic = LocalHapticFeedback.current
    val device = devices.firstOrNull { it.id == selectedId } ?: devices.firstOrNull()

    val press: (RemoteKey) -> Unit = { k ->
        if (haptics) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        vm.sendKey(k)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            device?.name ?: "Aucun appareil (mode démo)",
            style = MaterialTheme.typography.titleLarge
        )
        Text(
            if (device != null) device.type.label + " • " + device.ip
            else "Ajoutez un appareil dans l'onglet « Appareils ».",
            style = MaterialTheme.typography.bodySmall
        )

        Button(
            onClick = { press(RemoteKey.POWER) },
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
        ) {
            Text("⏻  Marche / Arrêt")
        }

        // Pavé directionnel
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            RBtn("▲", Modifier.size(76.dp)) { press(RemoteKey.UP) }
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                RBtn("◀", Modifier.size(76.dp)) { press(RemoteKey.LEFT) }
                Button(
                    onClick = { press(RemoteKey.OK) },
                    modifier = Modifier.size(76.dp),
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Text("OK")
                }
                RBtn("▶", Modifier.size(76.dp)) { press(RemoteKey.RIGHT) }
            }
            RBtn("▼", Modifier.size(76.dp)) { press(RemoteKey.DOWN) }
        }

        // Retour / Accueil / Menu
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            RBtn("Retour", Modifier.weight(1f)) { press(RemoteKey.BACK) }
            RBtn("Accueil", Modifier.weight(1f)) { press(RemoteKey.HOME) }
            RBtn("Menu", Modifier.weight(1f)) { press(RemoteKey.MENU) }
        }

        // Volume / Chaînes
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text("Volume", style = MaterialTheme.typography.labelLarge)
                RBtn("+", Modifier.size(76.dp)) { press(RemoteKey.VOL_UP) }
                RBtn("Muet", Modifier.size(76.dp)) { press(RemoteKey.MUTE) }
                RBtn("−", Modifier.size(76.dp)) { press(RemoteKey.VOL_DOWN) }
            }
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text("Chaîne", style = MaterialTheme.typography.labelLarge)
                RBtn("+", Modifier.size(76.dp)) { press(RemoteKey.CH_UP) }
                Spacer(Modifier.height(82.dp))
                RBtn("−", Modifier.size(76.dp)) { press(RemoteKey.CH_DOWN) }
            }
        }

        // Lecture
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            RBtn("⏪", Modifier.weight(1f)) { press(RemoteKey.REWIND) }
            RBtn("⏯", Modifier.weight(1f)) { press(RemoteKey.PLAY_PAUSE) }
            RBtn("⏩", Modifier.weight(1f)) { press(RemoteKey.FORWARD) }
            RBtn("⏹", Modifier.weight(1f)) { press(RemoteKey.STOP) }
        }

        // Pavé numérique
        val rows = listOf(listOf(1, 2, 3), listOf(4, 5, 6), listOf(7, 8, 9), listOf(0))
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            for (r in rows) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    for (n in r) {
                        RBtn(n.toString(), Modifier.size(width = 76.dp, height = 52.dp)) {
                            press(RemoteKey.valueOf("NUM_" + n))
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

// ---------------------------------------------------------------------------
// Appareils / connexion
// ---------------------------------------------------------------------------

private val IP_REGEX = Regex("^\\d{1,3}(\\.\\d{1,3}){3}$")

@Composable
fun DevicesScreen(vm: AppViewModel, onBackHome: () -> Unit) {
    val found by vm.found.collectAsStateWithLifecycle()
    val scanning by vm.scanning.collectAsStateWithLifecycle()
    val devices by vm.devices.collectAsStateWithLifecycle()

    var name by rememberSaveable { mutableStateOf("") }
    var ip by rememberSaveable { mutableStateOf("") }
    var typeName by rememberSaveable { mutableStateOf(DeviceType.ROKU.name) }
    var ipError by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Connexion des appareils", style = MaterialTheme.typography.headlineSmall)
                Text(
                    "Votre téléphone et vos appareils doivent être sur le même réseau Wi-Fi. " +
                        "Vous pouvez quitter cette page à tout moment avec la flèche en haut à gauche.",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }

        item {
            Button(
                onClick = { vm.scan() },
                enabled = !scanning,
                modifier = Modifier.fillMaxWidth()
            ) {
                if (scanning) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(18.dp),
                        strokeWidth = 2.dp,
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                    Spacer(Modifier.width(8.dp))
                    Text("Recherche en cours…")
                } else {
                    Text("Rechercher mes appareils")
                }
            }
        }

        if (found.isNotEmpty()) {
            item { Text("Appareils détectés", style = MaterialTheme.typography.titleMedium) }
            items(found, key = { it.ip }) { f ->
                FoundCard(
                    found = f,
                    already = devices.any { it.id == f.ip },
                    onAdd = { vm.addFound(f) }
                )
            }
        }

        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("Ajouter manuellement", style = MaterialTheme.typography.titleMedium)
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Nom (facultatif)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = ip,
                        onValueChange = {
                            ip = it
                            ipError = false
                        },
                        label = { Text("Adresse IP (ex. 192.168.1.20)") },
                        singleLine = true,
                        isError = ipError,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        for (t in DeviceType.values().filter { it != DeviceType.UNKNOWN }) {
                            FilterChip(
                                selected = typeName == t.name,
                                onClick = { typeName = t.name },
                                label = { Text(t.label) }
                            )
                        }
                    }
                    Button(
                        onClick = {
                            if (IP_REGEX.matches(ip.trim())) {
                                vm.addManual(name, ip, DeviceType.valueOf(typeName))
                                name = ""
                                ip = ""
                            } else {
                                ipError = true
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Ajouter l'appareil")
                    }
                }
            }
        }

        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text("Astuces", style = MaterialTheme.typography.titleMedium)
                    Text("• Samsung : acceptez la demande qui s'affiche sur la TV à la première commande.")
                    Text("• Kodi : activez « Autoriser le contrôle à distance via HTTP » (port 8080).")
                    Text("• Roku : activez « Contrôle réseau » dans les réglages du Roku.")
                    Text("• Si rien n'est trouvé, désactivez « l'isolation des clients » sur votre box.")
                }
            }
        }

        item {
            OutlinedButton(onClick = onBackHome, modifier = Modifier.fillMaxWidth()) {
                Text("Retour à la page principale")
            }
        }
    }
}

@Composable
private fun FoundCard(found: Found, already: Boolean, onAdd: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(found.name, style = MaterialTheme.typography.titleMedium)
                Text(found.type.label + " • " + found.ip, style = MaterialTheme.typography.bodySmall)
            }
            Button(onClick = onAdd, enabled = !already) {
                Text(if (already) "Ajouté" else "Ajouter")
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Réglages
// ---------------------------------------------------------------------------

@Composable
fun SettingsScreen(vm: AppViewModel) {
    val haptics by vm.haptics.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Vibration des touches", style = MaterialTheme.typography.titleMedium)
                Text(
                    "Retour haptique à chaque pression sur la télécommande.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
            Switch(checked = haptics, onCheckedChange = { vm.setHaptics(it) })
        }

        OutlinedButton(onClick = { vm.clearAll() }, modifier = Modifier.fillMaxWidth()) {
            Text("Supprimer tous les appareils")
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text("À propos", style = MaterialTheme.typography.titleMedium)
                Text("Télécommande Wi-Fi • version 1.0")
                Text(
                    "Appareils pris en charge : Roku, Samsung Smart TV (Tizen) et Kodi. " +
                        "Tout fonctionne en local : aucune donnée n'est envoyée sur Internet."
                )
            }
        }
    }
}
