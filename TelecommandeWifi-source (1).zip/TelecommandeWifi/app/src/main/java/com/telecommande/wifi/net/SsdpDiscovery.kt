package com.telecommande.wifi.net

import android.content.Context
import android.net.wifi.WifiManager
import com.telecommande.wifi.data.DeviceType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.SocketTimeoutException
import java.net.URL

data class Found(
    val ip: String,
    val name: String,
    val type: DeviceType,
    val model: String
)

object SsdpDiscovery {

    private class Raw(val ip: String) {
        var location: String = ""
        val text = StringBuilder()
    }

    suspend fun scan(context: Context, timeoutMs: Long = 4000): List<Found> =
        withContext(Dispatchers.IO) {
            val wifi = context.applicationContext
                .getSystemService(Context.WIFI_SERVICE) as WifiManager
            val lock = wifi.createMulticastLock("telecommande-ssdp")
            lock.setReferenceCounted(false)
            lock.acquire()

            val raws = LinkedHashMap<String, Raw>()
            val socket = DatagramSocket()
            try {
                socket.soTimeout = 400
                val group = InetAddress.getByName("239.255.255.250")
                val targets = listOf(
                    "ssdp:all",
                    "roku:ecp",
                    "urn:samsung.com:device:RemoteControlReceiver:1",
                    "urn:schemas-upnp-org:device:MediaRenderer:1"
                )

                fun sendSearches() {
                    for (st in targets) {
                        val msg = "M-SEARCH * HTTP/1.1\r\n" +
                            "HOST: 239.255.255.250:1900\r\n" +
                            "MAN: \"ssdp:discover\"\r\n" +
                            "MX: 2\r\n" +
                            "ST: " + st + "\r\n\r\n"
                        val data = msg.toByteArray()
                        socket.send(DatagramPacket(data, data.size, group, 1900))
                    }
                }

                sendSearches()
                delay(300)
                sendSearches()

                val buf = ByteArray(4096)
                val end = System.currentTimeMillis() + timeoutMs
                while (System.currentTimeMillis() < end) {
                    try {
                        val packet = DatagramPacket(buf, buf.size)
                        socket.receive(packet)
                        val ip = packet.address.hostAddress
                        if (ip != null) {
                            val text = String(packet.data, 0, packet.length, Charsets.UTF_8)
                            val raw = raws.getOrPut(ip) { Raw(ip) }
                            raw.text.append(text).append('\n')
                            if (raw.location.isEmpty()) {
                                val loc = header(text, "location")
                                if (loc != null) raw.location = loc
                            }
                        }
                    } catch (e: SocketTimeoutException) {
                        // on continue d'écouter jusqu'à la fin du délai
                    }
                }
            } finally {
                socket.close()
                if (lock.isHeld) lock.release()
            }

            val found: List<Found?> = coroutineScope {
                raws.values.map { raw -> async { buildFound(raw) } }.awaitAll()
            }
            found.filterNotNull()
        }

    private fun header(text: String, name: String): String? {
        for (line in text.split("\r\n", "\n")) {
            val i = line.indexOf(':')
            if (i > 0 && line.substring(0, i).trim().equals(name, ignoreCase = true)) {
                return line.substring(i + 1).trim()
            }
        }
        return null
    }

    private fun buildFound(raw: Raw): Found? {
        var info = raw.text.toString()
        var friendly = ""
        var manufacturer = ""
        var model = ""
        if (raw.location.startsWith("http")) {
            val xml = fetch(raw.location)
            if (xml != null) {
                friendly = tag(xml, "friendlyName")
                manufacturer = tag(xml, "manufacturer")
                model = tag(xml, "modelName")
                info += "\n" + xml.take(4000)
            }
        }
        val lower = info.lowercase()
        val type = when {
            lower.contains("roku") -> DeviceType.ROKU
            lower.contains("samsung") -> DeviceType.SAMSUNG
            lower.contains("kodi") || lower.contains("xbmc") -> DeviceType.KODI
            else -> DeviceType.UNKNOWN
        }
        if (type == DeviceType.UNKNOWN) return null

        val fallback = listOf(manufacturer, model).filter { it.isNotEmpty() }.joinToString(" ")
        val name = when {
            friendly.isNotEmpty() -> friendly
            fallback.isNotEmpty() -> fallback
            else -> type.label
        }
        return Found(raw.ip, name, type, model)
    }

    private fun fetch(url: String): String? {
        return try {
            val c = URL(url).openConnection() as HttpURLConnection
            try {
                c.connectTimeout = 1500
                c.readTimeout = 1500
                c.inputStream.bufferedReader().use { it.readText() }
            } finally {
                c.disconnect()
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun tag(xml: String, name: String): String {
        val regex = Regex("<" + name + ">(.*?)</" + name + ">", RegexOption.DOT_MATCHES_ALL)
        return regex.find(xml)?.groupValues?.get(1)?.trim() ?: ""
    }
}
