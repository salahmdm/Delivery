package com.telecommande.wifi.data

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

class DeviceStore(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("telecommande", Context.MODE_PRIVATE)

    fun loadDevices(): List<Device> {
        return try {
            val arr = JSONArray(prefs.getString("devices", "[]") ?: "[]")
            val out = ArrayList<Device>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val type = try {
                    DeviceType.valueOf(o.getString("type"))
                } catch (e: Exception) {
                    DeviceType.UNKNOWN
                }
                out.add(
                    Device(
                        id = o.getString("id"),
                        name = o.getString("name"),
                        ip = o.getString("ip"),
                        type = type,
                        token = o.optString("token", "")
                    )
                )
            }
            out
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun saveDevices(list: List<Device>) {
        val arr = JSONArray()
        for (d in list) {
            arr.put(
                JSONObject()
                    .put("id", d.id)
                    .put("name", d.name)
                    .put("ip", d.ip)
                    .put("type", d.type.name)
                    .put("token", d.token)
            )
        }
        prefs.edit().putString("devices", arr.toString()).apply()
    }

    fun loadSelected(): String? = prefs.getString("selected", null)

    fun saveSelected(id: String?) {
        prefs.edit().putString("selected", id).apply()
    }

    fun loadHaptics(): Boolean = prefs.getBoolean("haptics", true)

    fun saveHaptics(value: Boolean) {
        prefs.edit().putBoolean("haptics", value).apply()
    }
}
