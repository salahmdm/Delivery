package com.telecommande.wifi.ui

import android.app.Application
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.telecommande.wifi.data.Device
import com.telecommande.wifi.data.DeviceStore
import com.telecommande.wifi.data.DeviceType
import com.telecommande.wifi.data.RemoteKey
import com.telecommande.wifi.net.Found
import com.telecommande.wifi.net.KodiDriver
import com.telecommande.wifi.net.RemoteDriver
import com.telecommande.wifi.net.RokuDriver
import com.telecommande.wifi.net.SamsungDriver
import com.telecommande.wifi.net.SsdpDiscovery
import com.telecommande.wifi.net.UnsupportedDriver
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class AppViewModel(app: Application) : AndroidViewModel(app) {

    private val store = DeviceStore(app)

    private val _devices = MutableStateFlow(store.loadDevices())
    val devices: StateFlow<List<Device>> = _devices.asStateFlow()

    private val _selectedId = MutableStateFlow<String?>(store.loadSelected())
    val selectedId: StateFlow<String?> = _selectedId.asStateFlow()

    private val _found = MutableStateFlow<List<Found>>(emptyList())
    val found: StateFlow<List<Found>> = _found.asStateFlow()

    private val _scanning = MutableStateFlow(false)
    val scanning: StateFlow<Boolean> = _scanning.asStateFlow()

    private val _haptics = MutableStateFlow(store.loadHaptics())
    val haptics: StateFlow<Boolean> = _haptics.asStateFlow()

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val messages: SharedFlow<String> = _messages.asSharedFlow()

    private val drivers = HashMap<String, RemoteDriver>()

    private fun toast(message: String) {
        _messages.tryEmit(message)
    }

    private fun isOnWifi(): Boolean {
        return try {
            val cm = getApplication<Application>()
                .getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val caps = cm.getNetworkCapabilities(cm.activeNetwork)
            caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
        } catch (e: Exception) {
            false
        }
    }

    fun currentDevice(): Device? {
        val list = _devices.value
        return list.firstOrNull { it.id == _selectedId.value } ?: list.firstOrNull()
    }

    fun scan() {
        if (_scanning.value) return
        if (!isOnWifi()) {
            toast("Connectez ce téléphone au même réseau Wi-Fi que vos appareils.")
        }
        viewModelScope.launch {
            _scanning.value = true
            _found.value = emptyList()
            try {
                val result = SsdpDiscovery.scan(getApplication<Application>())
                _found.value = result
                if (result.isEmpty()) {
                    toast("Aucun appareil trouvé. Ajoutez-le manuellement avec son adresse IP.")
                }
            } catch (e: Exception) {
                toast("Recherche impossible : " + (e.message ?: "erreur réseau"))
            } finally {
                _scanning.value = false
            }
        }
    }

    fun addFound(f: Found) {
        addDevice(Device(id = f.ip, name = f.name, ip = f.ip, type = f.type))
    }

    fun addManual(name: String, ip: String, type: DeviceType) {
        val finalName = if (name.isBlank()) type.label else name.trim()
        addDevice(Device(id = ip.trim(), name = finalName, ip = ip.trim(), type = type))
    }

    private fun addDevice(device: Device) {
        drivers.remove(device.id)?.close()
        val updated = _devices.value.filter { it.id != device.id } + device
        _devices.value = updated
        store.saveDevices(updated)
        selectDevice(device.id)
        toast("« " + device.name + " » ajouté.")
    }

    fun selectDevice(id: String) {
        _selectedId.value = id
        store.saveSelected(id)
    }

    fun removeDevice(id: String) {
        drivers.remove(id)?.close()
        val updated = _devices.value.filter { it.id != id }
        _devices.value = updated
        store.saveDevices(updated)
        if (_selectedId.value == id) {
            _selectedId.value = null
            store.saveSelected(null)
        }
    }

    fun clearAll() {
        drivers.values.forEach { it.close() }
        drivers.clear()
        _devices.value = emptyList()
        _selectedId.value = null
        store.saveDevices(emptyList())
        store.saveSelected(null)
        toast("Tous les appareils ont été supprimés.")
    }

    fun setHaptics(value: Boolean) {
        _haptics.value = value
        store.saveHaptics(value)
    }

    private fun updateToken(id: String, token: String) {
        _devices.update { list -> list.map { if (it.id == id) it.copy(token = token) else it } }
        store.saveDevices(_devices.value)
    }

    private fun driverFor(d: Device): RemoteDriver {
        return drivers.getOrPut(d.id) {
            when (d.type) {
                DeviceType.ROKU -> RokuDriver(d.ip)
                DeviceType.SAMSUNG -> SamsungDriver(d.ip, d.token) { t -> updateToken(d.id, t) }
                DeviceType.KODI -> KodiDriver(d.ip)
                DeviceType.UNKNOWN -> UnsupportedDriver()
            }
        }
    }

    fun sendKey(key: RemoteKey) {
        val device = currentDevice()
        if (device == null) {
            toast("Mode démo : aucun appareil. Ajoutez-en un dans l'onglet « Appareils ».")
            return
        }
        viewModelScope.launch {
            val result = driverFor(device).send(key)
            result.onFailure { e -> toast(e.message ?: "La commande a échoué.") }
        }
    }

    override fun onCleared() {
        drivers.values.forEach { it.close() }
        drivers.clear()
        super.onCleared()
    }
}
