package com.example.telecommandewifi

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.concurrent.thread

/** Prototype Roku ECP : les commandes sont réellement envoyées en HTTP sur le réseau local. */
class MainActivity : Activity() {
    private lateinit var ip: EditText
    private lateinit var status: TextView
    private lateinit var container: LinearLayout
    private var selectedProtocol = "Roku (ECP)"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16,20,31)
        window.navigationBarColor = Color.rgb(16,20,31)
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.rgb(16,20,31))
        container = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22,30,22,28) }
        scroll.addView(container)
        setContentView(scroll)
        title("Télécommande Wi-Fi")
        text("Prototype fonctionnel Roku • contrôle local, sans compte")
        ip = EditText(this).apply { hint = "Adresse IP du Roku (ex. 192.168.1.20)"; setSingleLine(); setText(getPreferences(0).getString("ip", "")); setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY) }
        container.addView(ip)
        val protocols = Spinner(this)
        protocols.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("Roku (ECP)", "Autres marques : à développer"))
        protocols.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) { selectedProtocol = if (position == 0) "Roku (ECP)" else "Non pris en charge" }
        }
        container.addView(protocols)
        status = TextView(this).apply { setTextColor(Color.rgb(170,210,255)); textSize = 14f; text = "Saisis l'adresse IP puis teste la connexion."; setPadding(0,14,0,20) }
        container.addView(status)
        row("Tester connexion" to "__test", "Accueil" to "Home")
        row("⏻" to "Power", "Retour" to "Back", "Menu" to "Info")
        row("" to "", "▲" to "Up", "" to "")
        row("◀" to "Left", "OK" to "Select", "▶" to "Right")
        row("" to "", "▼" to "Down", "" to "")
        row("Vol +" to "VolumeUp", "Muet" to "VolumeMute", "Vol −" to "VolumeDown")
        row("Chaîne +" to "ChannelUp", "Chaîne −" to "ChannelDown")
        row("⏮" to "Rev", "⏯" to "Play", "⏭" to "Fwd")
        row("1" to "Lit_1", "2" to "Lit_2", "3" to "Lit_3")
        row("4" to "Lit_4", "5" to "Lit_5", "6" to "Lit_6")
        row("7" to "Lit_7", "8" to "Lit_8", "9" to "Lit_9")
        row("*" to "Info", "0" to "Lit_0", "Entrée" to "Enter")
        text("Certaines commandes, notamment le volume et les chaînes, dépendent des capacités du Roku et du téléviseur associé.")
    }
    private fun title(s: String) { container.addView(TextView(this).apply { text = s; textSize = 26f; setTextColor(Color.WHITE); setPadding(0,0,0,12) }) }
    private fun text(s: String) { container.addView(TextView(this).apply { text = s; textSize = 15f; setTextColor(Color.LTGRAY); setPadding(0,0,0,14) }) }
    private fun row(vararg buttons: Pair<String,String>) {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        buttons.forEach { (label, command) ->
            val b = Button(this).apply { text = label; isEnabled = command.isNotEmpty(); textSize = 15f; minHeight = 56; setOnClickListener { send(command) } }
            r.addView(b, LinearLayout.LayoutParams(0, 62, 1f))
        }
        container.addView(r)
    }
    private fun send(key: String) {
        val host = ip.text.toString().trim()
        if (!Regex("^(\\d{1,3}\\.){3}\\d{1,3}$").matches(host) || host.split('.').any { it.toInt() > 255 }) { status.text = "Adresse IPv4 invalide"; return }
        if (selectedProtocol != "Roku (ECP)") { status.text = "Ce protocole n'est pas encore implémenté"; return }
        getPreferences(0).edit().putString("ip", host).apply()
        status.text = "Envoi…"
        thread {
            try {
                val endpoint = if (key == "__test") "query/device-info" else "keypress/${URLEncoder.encode(key, "UTF-8")}" 
                val conn = (URL("http://$host:8060/$endpoint").openConnection() as HttpURLConnection)
                conn.requestMethod = if (key == "__test") "GET" else "POST"
                conn.connectTimeout = 2000; conn.readTimeout = 2000
                val code = conn.responseCode
                conn.disconnect()
                runOnUiThread { status.text = if (code in 200..299) "✓ ${if (key == "__test") "Roku accessible" else "Commande $key envoyée"}" else "Erreur HTTP $code" }
            } catch (e: Exception) { runOnUiThread { status.text = "Connexion impossible : ${e.javaClass.simpleName}. Vérifie le Wi-Fi et l'IP." } }
        }
    }
}
