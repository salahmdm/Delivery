# Télécommande Wi-Fi — prototype Android

**État réel : prototype Roku ECP seulement.** L'application envoie des commandes HTTP locales vers un appareil Roku. Elle n'est PAS une télécommande universelle complète et n'a pas été testée sur un appareil réel.

## Construire l'APK
1. Importer le contenu de ce dossier dans un dépôt GitHub.
2. Ouvrir l'onglet Actions, lancer **Build APK** (ou pousser un commit).
3. Télécharger l'artifact **TelecommandeWifi-debug-apk**, extraire `app-debug.apk` et l'installer sur Android.

Alternativement : ouvrir le projet avec Android Studio, synchroniser Gradle, puis Build > Build APK(s).

## Tester
Sur le même réseau Wi-Fi qu'un Roku compatible ECP, saisir son IPv4 et choisir « Tester connexion ». Les touches envoient des requêtes POST `/keypress/<key>` sur le port 8060. Certaines touches ne sont pas prises en charge par tous les appareils Roku.

## Limites
Pas encore de découverte automatique, appairage, pilote Android TV/Samsung/LG/Sony, widget, chiffrement de jetons, pièces, clavier, pavé tactile, pont IR ou tests automatisés. Ce dépôt n'est pas conforme au cahier des charges MVP complet.
