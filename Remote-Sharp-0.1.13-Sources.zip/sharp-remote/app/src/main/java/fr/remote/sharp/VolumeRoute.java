package fr.remote.sharp;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.*;
import android.graphics.drawable.Icon;
import android.widget.Toast;
import java.util.Collections;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

public final class VolumeRoute {
    static android.content.SharedPreferences prefs;
    static Application app;
    static final Handler ui=new Handler(Looper.getMainLooper());
    static final ExecutorService worker=Executors.newSingleThreadExecutor();
    private static final AtomicBoolean busy=new AtomicBoolean();
    private static Activity current;
    public interface AppleSettings { void showAppleSettings(); }
    static java.lang.ref.WeakReference<Activity> main=new java.lang.ref.WeakReference<>(null);
    public static void showHub(){if(current!=null)current.startActivity(new Intent(current,SettingsHub.class));}
    static void apple(Activity hub){
        Activity a=main.get();
        if(a instanceof AppleSettings && !a.isDestroyed() && !a.isFinishing()){((AppleSettings)a).showAppleSettings();hub.finish();return;}
        Intent start=app.getPackageManager().getLaunchIntentForPackage(app.getPackageName());
        if(start!=null){start.putExtra("appleSettings",true);hub.startActivity(start);hub.finish();}
    }
    public static void init(Application a){
        app=a;prefs=a.getSharedPreferences("sharp-speakers",0);
        a.registerActivityLifecycleCallbacks(new Application.ActivityLifecycleCallbacks(){
            public void onActivityResumed(Activity x){current=x;if(x instanceof AppleSettings){main=new java.lang.ref.WeakReference<>(x);if(x.getIntent().getBooleanExtra("appleSettings",false)){x.getIntent().removeExtra("appleSettings");((AppleSettings)x).showAppleSettings();}}}
            public void onActivityPaused(Activity x){if(current==x)current=null;}
            public void onActivityCreated(Activity x,Bundle b){}
            public void onActivityDestroyed(Activity x){}
            public void onActivityStarted(Activity x){}
            public void onActivityStopped(Activity x){}
            public void onActivitySaveInstanceState(Activity x,Bundle b){}
        });
        Intent settings=new Intent(a,SettingsHub.class).setAction(Intent.ACTION_VIEW);
        ShortcutInfo shortcut=new ShortcutInfo.Builder(a,"sharp-volume").setShortLabel("Réglages")
            .setIcon(Icon.createWithResource(a,android.R.drawable.ic_menu_preferences)).setIntent(settings).build();
        try{a.getSystemService(ShortcutManager.class).addDynamicShortcuts(Collections.singletonList(shortcut));}catch(RuntimeException ignored){}
    }
    public static boolean intercept(int code){
        if(code!=8&&code!=9 || prefs==null || !prefs.getBoolean("direct",false))return false;
        final String host=prefs.getString("ip","");
        if(host.isEmpty()){ui.post(()->{if(current!=null && !(current instanceof SharpSettings))current.startActivity(new Intent(current,SharpSettings.class));});return true;}
        if(!busy.compareAndSet(false,true))return true;
        SharpWire.Target target=new SharpWire.Target(host,prefs.getInt("port",10002),prefs.getString("url",""),prefs.getString("service",""));
        worker.execute(()->{try{SharpWire.step(target,code==8?1:-1);}
            catch(Exception e){ui.post(()->Toast.makeText(app,"Volume Sharp indisponible. Ouvre Réglages → Téléviseur Sharp.",Toast.LENGTH_LONG).show());}
            finally{busy.set(false);}
        });return true;
    }
}
