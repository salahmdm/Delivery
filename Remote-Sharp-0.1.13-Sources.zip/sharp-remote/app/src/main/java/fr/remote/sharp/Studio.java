package fr.remote.sharp;

import android.app.Activity;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.view.*;
import android.widget.*;

final class Studio {
    static final int BG=0xff10181c, CARD=0xff1b282e, FG=0xfff1f6f5, DIM=0xffb5c7c7, MINT=0xff87dfc8;
    static int dp(Context c,int n){return Math.round(c.getResources().getDisplayMetrics().density*n);}
    static void window(Activity a){a.getWindow().setStatusBarColor(BG);a.getWindow().setNavigationBarColor(BG);}
    static GradientDrawable shape(Context c,int color,int r){
        GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(c,r));return d;
    }
    static void add(LinearLayout parent,View v){
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=dp(parent.getContext(),8);parent.addView(v,lp);
    }
    static Button button(Context c,String title){
        Button b=new Button(c);b.setText(title);b.setAllCaps(false);b.setTextSize(16);b.setMinHeight(dp(c,50));
        b.setTextColor(new ColorStateList(new int[][]{new int[]{-android.R.attr.state_enabled},new int[]{}},new int[]{0xff85969a,FG}));
        b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x4487dfc8),shape(c,CARD,14),null));return b;
    }
    static TextView text(Context c,String title,int size,int color,boolean bold){
        TextView t=new TextView(c);t.setText(title);t.setTextColor(color);t.setTextSize(size);
        if(bold)t.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));return t;
    }
}
