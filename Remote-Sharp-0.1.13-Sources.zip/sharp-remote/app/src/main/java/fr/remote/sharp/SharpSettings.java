package fr.remote.sharp;

import android.app.Activity;
import android.os.Bundle;
import android.content.*;
import android.net.*;
import android.text.InputType;
import android.widget.*;
import java.net.*;

public final class SharpSettings extends Activity {
    LinearLayout root;
    EditText ip,port;
    Spinner mode;
    TextView log;
    Button test,minus,plus,restore,keyDown,keyUp,smart;
    SharpWire.Target active;
    final String[] modes={"Automatique","AQUOS IP uniquement","UPnP uniquement"};
    TextView label(String text){TextView v=new TextView(this);v.setText(text);v.setTextColor(Studio.FG);v.setPadding(0,Studio.dp(this,8),0,Studio.dp(this,4));root.addView(v);return v;}
    Button button(String name,Runnable action){Button v=Studio.button(this,name);Studio.add(root,v);v.setOnClickListener(w->action.run());return v;}
    EditText input(String name,String value,boolean number){
        label(name);EditText v=new EditText(this);v.setSingleLine();
        if(number)v.setInputType(InputType.TYPE_CLASS_NUMBER);
        v.setText(value);v.setTextColor(Studio.FG);v.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Studio.MINT));root.addView(v);return v;
    }
    @Override public void onCreate(Bundle b){
        super.onCreate(b);Studio.window(this);setTitle("Connexion Sharp");ScrollView sc=new ScrollView(this);root=new LinearLayout(this);
        int pad=Math.round(20*getResources().getDisplayMetrics().density);root.setPadding(pad,pad*2,pad,pad);root.setOrientation(1);root.setBackgroundColor(Studio.BG);sc.addView(root);setContentView(sc);
        label("Téléviseur Sharp").setTextSize(30);label("LC-55CFE6352E  ·  Haut-parleurs intégrés");
        ip=input("Adresse IPv4 du téléviseur",VolumeRoute.prefs.getString("draftIP",VolumeRoute.prefs.getString("ip","192.168.1.14")),false);
        port=input("Port AQUOS IP",String.valueOf(VolumeRoute.prefs.getInt("draftPort",10002)),true);
        label("Essai sur l’entrée HDMI");
        smart=button("Essayer SmartCenter · Volume −",()->tryKey(-1,true));
        keyDown=button("Touche Sharp · Volume −",()->tryKey(-1,false));
        keyUp=button("Touche Sharp · Volume +",()->tryKey(1,false));
        label("Diagnostic des autres modes");mode=new Spinner(this);ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,modes);mode.setAdapter(adapter);root.addView(mode);mode.setSelection(VolumeRoute.prefs.getInt("draftMode",0));
        test=button("Enregistrer et tester la connexion",()->diagnose());
        minus=button("Tester Volume −",()->change(-1));plus=button("Tester Volume +",()->change(1));
        restore=button("Fermer les réglages Sharp",this::finish);
        log=label("Connexion non testée dans cet écran.");log.setTextIsSelectable(true);
        button("Copier le diagnostic",()->{android.content.ClipboardManager c=getSystemService(android.content.ClipboardManager.class);c.setPrimaryClip(ClipData.newPlainText("Diagnostic Sharp",log.getText()));});
        controls(false);
    }
    void controls(boolean busy){
        smart.setEnabled(!busy);keyDown.setEnabled(!busy);keyUp.setEnabled(!busy);ip.setEnabled(!busy);port.setEnabled(!busy);mode.setEnabled(!busy);test.setEnabled(!busy);restore.setEnabled(!busy);
        minus.setEnabled(!busy&&active!=null);plus.setEnabled(!busy&&active!=null);
    }
    String phone(){
        ConnectivityManager cm=getSystemService(ConnectivityManager.class);
        Network n=cm.getActiveNetwork();NetworkCapabilities caps=cm.getNetworkCapabilities(n);
        LinkProperties lp=cm.getLinkProperties(n);
        String name=caps!=null&&caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)?"Wi-Fi":"réseau actif";
        if(lp!=null)for(LinkAddress a:lp.getLinkAddresses())if(a.getAddress() instanceof Inet4Address)return "Téléphone ("+name+") · "+a;
        return "Téléphone · aucune IPv4 active identifiée";
    }
    void line(String s){runOnUiThread(()->{if(!isDestroyed())log.append("\n"+s);});}
    boolean live(){return !isFinishing()&&!isDestroyed();}
    void tryKey(int delta,boolean smartCenter){
        String addr=ip.getText().toString().trim();int number;
        try{SharpWire.host(addr);number=smartCenter?56789:Integer.parseInt(port.getText().toString());if(number<1||number>65535)throw new Exception();}
        catch(Exception e){log.setText("Adresse IPv4 ou port incorrect.");return;}
        if(android.os.Build.VERSION.SDK_INT>=37 && checkSelfPermission("android.permission.ACCESS_LOCAL_NETWORK")!=android.content.pm.PackageManager.PERMISSION_GRANTED){
            log.setText("Autorise le réseau local, puis réessaie.");requestPermissions(new String[]{"android.permission.ACCESS_LOCAL_NETWORK"},47);return;}
        String protocol=smartCenter?"SmartCenter":"RCKY";
        SharpWire.Target t=new SharpWire.Target(addr,number,smartCenter?"http://"+addr+":56789/apps/SmartCenter":"",protocol);
        log.setText(phone()+"\nTouche "+(delta>0?"Volume +":"Volume −")+" vers "+addr+":"+number);
        controls(true);
        VolumeRoute.worker.execute(()->{
            try{
                if(smartCenter){SharpWire.identifySmartCenter(t);line("Service SmartCenter identifié.");}
                SharpWire.step(t,delta);
                line("La TV a répondu OK à la touche.");
                runOnUiThread(()->{if(live())new android.app.AlertDialog.Builder(this)
                    .setTitle("Le son de la vidéo a-t-il changé ?")
                    .setMessage("Confirme uniquement si tu entends le volume changer sur la Sharp.")
                    .setNegativeButton("Aucun effet",(dialog,w)->{line("Aucun effet audible sur HDMI avec "+protocol+".");VolumeRoute.prefs.edit().putString("hearing","Aucun effet audible · "+protocol+" · "+addr).apply();})
                    .setPositiveButton("Oui, utiliser ces touches",(dialog,w)->{
                        VolumeRoute.prefs.edit().putString("ip",addr).putInt("port",number).putString("draftIP",addr)
                            .putString("url",t.url).putString("service",protocol).putBoolean("direct",true).putString("hearing","Effet audible confirmé · "+protocol+" · "+addr).apply();
                        line("Touches + et − de la télécommande affectées à la Sharp.");
                    }).show();});
            }catch(Exception e){line(protocol+" indisponible ou commande non confirmée · "+e.getMessage());}
            finally{runOnUiThread(()->{if(live())controls(false);});}
        });
    }
    void diagnose(){
        String addr=ip.getText().toString().trim();int p;int m=mode.getSelectedItemPosition();
        active=null;controls(false);
        try{SharpWire.host(addr);p=Integer.parseInt(port.getText().toString());if(p<1||p>65535)throw new Exception();}
        catch(Exception e){log.setText("Vérifie l’adresse IPv4 locale et le port (1 à 65535).");return;}
        VolumeRoute.prefs.edit().putString("draftIP",addr).putInt("draftPort",p).putInt("draftMode",m).apply();
        log.setText(phone()+"\nTV · "+addr+" · "+modes[m]);
        if(android.os.Build.VERSION.SDK_INT>=37 && checkSelfPermission("android.permission.ACCESS_LOCAL_NETWORK")!=android.content.pm.PackageManager.PERMISSION_GRANTED){
            line("Accès au réseau local à autoriser. Relance le test après autorisation.");requestPermissions(new String[]{"android.permission.ACCESS_LOCAL_NETWORK"},47);return;
        }
        controls(true);
        VolumeRoute.worker.execute(()->{try{
            try{line(InetAddress.getByName(addr).isReachable(1100)?"Réponse réseau reçue de "+addr+".":"Sonde réseau sans réponse. Vérification des services…");}
            catch(Exception e){line("Sonde réseau indisponible. Vérification des services…");}
            SharpWire.Target t=SharpWire.detect(addr,p,m,this::line);int level=SharpWire.read(t);
            runOnUiThread(()->{if(!live())return;active=t;
                
                line("Communication confirmée · "+(t.url.isEmpty()?"AQUOS IP":"UPnP")+" · volume lu "+level+".");controls(false);});
        }catch(Exception e){line("Volume non confirmé · "+e.getMessage());runOnUiThread(()->{if(live())controls(false);});}});
    }
    void heard(SharpWire.Target t,boolean ok){
        String result=ok?"Changement audible confirmé":"Aucun effet audible sur HDMI";
        String protocol=t.url.isEmpty()?"AQUOS IP":"UPnP";
        VolumeRoute.prefs.edit().putString("hearing",result+" · "+protocol+" · "+t.host).apply();
        if(ok)VolumeRoute.prefs.edit().putString("ip",t.host).putInt("port",t.port).putString("url",t.url).putString("service",t.service).apply();
        line(result+" · "+protocol+".");
        if(!ok){mode.setSelection(t.url.isEmpty()?2:1);active=null;controls(false);
            line("Autre protocole sélectionné. Touche Enregistrer et tester la connexion pour l’essayer.");}
    }
    void change(int delta){
        SharpWire.Target t=active;if(t==null)return;
        if(!ip.getText().toString().trim().equals(t.host)||!port.getText().toString().equals(String.valueOf(t.port))||mode.getSelectedItemPosition()!=VolumeRoute.prefs.getInt("draftMode",0)){log.setText("Relance le test après modification des réglages.");active=null;controls(false);return;}
        controls(true);VolumeRoute.worker.execute(()->{try{
            int before=SharpWire.read(t);int expected=Math.max(0,Math.min(100,before+delta));
            if(expected==before){line("Limite atteinte · volume "+before+". Essaie l’autre touche.");return;}
            SharpWire.step(t,delta);int after=SharpWire.read(t);
            for(int i=0;i<3&&after==before;i++){Thread.sleep(250);after=SharpWire.read(t);}
            line("Valeur renvoyée par la TV · "+before+" → "+after+".");
            if(after==expected)runOnUiThread(()->{if(live())new android.app.AlertDialog.Builder(this)
                .setTitle("Le son a-t-il changé sur la Sharp ?")
                .setMessage("Écoute la vidéo sur l’entrée HDMI de l’Apple TV.")
                .setPositiveButton("Oui",(dialog,w)->heard(t,true)).setNegativeButton("Aucun effet",(dialog,w)->heard(t,false)).show();});
            else line("Variation réseau attendue non observée.");
        }catch(Exception e){line("Échec de la commande · "+e.getMessage());}finally{runOnUiThread(()->{if(live())controls(false);});}});
    }
}
