package fr.remote.sharp;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.*;
import org.xml.sax.InputSource;

public final class SharpWire {
    public static final class Target {
        public final String host, url, service;
        public final int port;
        public Target(String h,int p,String u,String s){host=h;port=p;url=u;service=s;}
    }
    static String host(String s) throws IOException {
        if (!s.matches("([0-9]{1,3}\\.){3}[0-9]{1,3}")) throw new IOException("Saisis l’adresse IPv4 du téléviseur.");
        for(String part:s.split("\\.")) if(Integer.parseInt(part)>255 || (part.length()>1 && part.startsWith("0"))) throw new IOException("Adresse IPv4 incorrecte.");
        InetAddress addr=InetAddress.getByName(s);
        if(!(addr.isSiteLocalAddress()||addr.isLinkLocalAddress())) throw new IOException("Utilise l’adresse locale de la Sharp.");
        return s;
    }
    private static String command(Target t,String command) throws IOException {
        try(Socket socket=new Socket()){
            socket.connect(new InetSocketAddress(t.host,t.port),1500);socket.setSoTimeout(1600);
            socket.getOutputStream().write((command+"\r").getBytes(StandardCharsets.US_ASCII));
            StringBuilder response=new StringBuilder();InputStream in=socket.getInputStream();
            for(int i=0;i<64;i++){int b=in.read();if(b<0||b=='\r'||b=='\n')break;response.append((char)b);}
            return response.toString().trim();
        }
    }
    private static int level(String s) throws IOException {
        if(!s.matches("[0-9]{1,3}")||Integer.parseInt(s)>100)throw new IOException("Volume illisible ou accès refusé.");
        return Integer.parseInt(s);
    }
    private static URL localURL(String host,URL base,String path) throws IOException{
        URL u=new URL(base,path);
        if(!u.getProtocol().equals("http")||!u.getHost().equals(host)||u.getUserInfo()!=null)throw new IOException("Adresse de service non locale.");
        return u;
    }
    private static Document xml(URL u,String action,String envelope) throws Exception{
        HttpURLConnection conn=(HttpURLConnection)u.openConnection();
        conn.setConnectTimeout(1800);conn.setReadTimeout(2200);conn.setInstanceFollowRedirects(false);conn.setUseCaches(false);
        try{
            if(action!=null){
                conn.setRequestMethod("POST");conn.setDoOutput(true);conn.setRequestProperty("Content-Type","text/xml; charset=utf-8");
                conn.setRequestProperty("SOAPACTION","\""+action+"\"");
                try(OutputStream out=conn.getOutputStream()){out.write(envelope.getBytes(StandardCharsets.UTF_8));}
            }
            if(conn.getResponseCode()!=200)throw new IOException("Commande refusée (HTTP "+conn.getResponseCode()+").");
            try(InputStream in=conn.getInputStream();ByteArrayOutputStream data=new ByteArrayOutputStream()){
                byte[] buf=new byte[4096];int n;
                while((n=in.read(buf))>=0){if(data.size()+n>262144)throw new IOException("Réponse trop longue.");data.write(buf,0,n);}
                String body=data.toString("UTF-8");
                if(body.toUpperCase(Locale.ROOT).contains("<!DOCTYPE"))throw new IOException("Format XML non pris en charge.");
                DocumentBuilderFactory f=DocumentBuilderFactory.newInstance();f.setNamespaceAware(true);f.setExpandEntityReferences(false);
                return f.newDocumentBuilder().parse(new InputSource(new StringReader(body)));
            }
        }finally{conn.disconnect();}
    }
    private static String field(Element el,String tag){
        NodeList n=el.getElementsByTagNameNS("*",tag);return n.getLength()==0?"":n.item(0).getTextContent().trim();
    }
    private static Document soap(Target t,String action,String args) throws Exception {
        String body="<?xml version=\"1.0\"?><s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\"><s:Body><u:"+action+" xmlns:u=\""+t.service+"\"><InstanceID>0</InstanceID><Channel>Master</Channel>"+args+"</u:"+action+"></s:Body></s:Envelope>";
        return xml(localURL(t.host,null,t.url),t.service+"#"+action,body);
    }
    public static int read(Target t) throws Exception{
        return level(t.url.isEmpty()?command(t,"VOLM?   "):field(soap(t,"GetVolume","").getDocumentElement(),"CurrentVolume"));
    }
    static void identifySmartCenter(Target t) throws Exception {
        URL url=localURL(t.host,null,t.url);
        Element root=xml(url,null,null).getDocumentElement();
        if(!"service".equals(root.getLocalName()) || !"SmartCenter".equalsIgnoreCase(field(root,"name")))
            throw new IOException("Service SmartCenter non identifié.");
    }
    private static void smartKey(Target t,int delta) throws Exception {
        HttpURLConnection c=(HttpURLConnection)localURL(t.host,null,t.url).openConnection();
        try{
            c.setInstanceFollowRedirects(false);c.setConnectTimeout(1800);c.setReadTimeout(2200);
            c.setRequestMethod("POST");c.setDoOutput(true);
            c.setRequestProperty("application_name","vestel smart center");
            c.setRequestProperty("Content-Type","text/plain; charset=ISO-8859-1");
            String key=delta>0?"1016":"1017";
            try(OutputStream out=c.getOutputStream()){
                out.write(("<?xml version='1.0' ?><remote><key code='"+key+"'/></remote>").getBytes(StandardCharsets.ISO_8859_1));
            }
            int status=c.getResponseCode();if(status<200||status>=300)throw new IOException("Touche refusée (HTTP "+status+").");
        }finally{c.disconnect();}
    }
    public static void step(Target t,int delta) throws Exception{
        if("SmartCenter".equals(t.service)){smartKey(t,delta);return;}
        if("RCKY".equals(t.service)){
            String reply=command(t,delta>0?"RCKY33  ":"RCKY32  ");
            if(!"OK".equalsIgnoreCase(reply))throw new IOException("Réponse RCKY : "+(reply.isEmpty()?"vide":reply));
            return;
        }
        int old=read(t),next=Math.max(0,Math.min(100,old+Integer.signum(delta)));if(old==next)return;
        if(t.url.isEmpty()){
            if(!"OK".equalsIgnoreCase(command(t,String.format(Locale.ROOT,"VOLM%-4d",next))))throw new IOException("La Sharp a refusé le changement de volume.");
        }else soap(t,"SetVolume","<DesiredVolume>"+next+"</DesiredVolume>");
    }
    static void describeActions(String ip,URL base,Element service,Report report) throws Exception {
        String path=field(service,"SCPDURL");
        if(path.isEmpty())throw new IOException("Adresse de description absente.");
        URL endpoint=localURL(ip,base,path);
        report.line("Description AwoX · "+endpoint);
        Element root=xml(endpoint,null,null).getDocumentElement();
        NodeList actions=root.getElementsByTagNameNS("*","action");
        if(actions.getLength()==0)report.line("Aucune action déclarée dans la description.");
        for(int i=0;i<actions.getLength();i++){
            Element action=(Element)actions.item(i);
            StringBuilder entry=new StringBuilder("Action AwoX · ").append(field(action,"name"));
            NodeList args=action.getElementsByTagNameNS("*","argument");
            for(int j=0;j<args.getLength();j++){
                Element arg=(Element)args.item(j);
                entry.append(" · ").append(field(arg,"direction")).append(" ").append(field(arg,"name")).append(" → ").append(field(arg,"relatedStateVariable"));
            }
            report.line(entry.toString());
        }
        describeStateTable(root,report);
    }
    static void describeStateTable(Element root, Report report){
        NodeList tables=root.getElementsByTagNameNS("*","serviceStateTable");
        if(tables.getLength()==0){report.line("AwoX · table des variables absente.");return;}
        report.line("Variables AwoX");
        Element table=(Element)tables.item(0);
        NodeList vars=table.getElementsByTagNameNS("*","stateVariable");
        if(vars.getLength()==0)report.line("Table présente, aucune variable déclarée.");
        for(int i=0;i<vars.getLength();i++){
            Element v=(Element)vars.item(i);
            StringBuilder line=new StringBuilder(field(v,"name")).append(" · ").append(field(v,"dataType"));
            String def=field(v,"defaultValue");
            if(!def.isEmpty())line.append(" · défaut = ").append(def);
            NodeList values=v.getElementsByTagNameNS("*","allowedValue");
            for(int j=0;j<values.getLength();j++)line.append(j==0?" · valeurs : ":", ").append(values.item(j).getTextContent().trim());
            for(String key:new String[]{"minimum","maximum","step"}){
                String value=field(v,key);
                if(!value.isEmpty())line.append(" · ").append(key).append(" = ").append(value);
            }
            if(values.getLength()==0 && v.getElementsByTagNameNS("*","allowedValueRange").getLength()==0)
                line.append(" · aucune liste ni plage publiée");
            report.line(line.toString());
        }
    }
    public interface Report { void line(String text); }
    public static Target detect(String ip,int port,int mode,Report report) throws Exception {
        host(ip);if(port<1||port>65535)throw new IOException("Port incorrect.");
        Target tcp=new Target(ip,port,"","");
        if(mode!=2){
            try(Socket check=new Socket()){
                check.connect(new InetSocketAddress(ip,port),1500);
                report.line("TCP "+port+" ouvert sur "+ip+".");
                read(tcp);return tcp;
            }catch(Exception unavailable){report.line("AQUOS indisponible · "+unavailable.getMessage());}
        }
        if(mode==1)throw new IOException("Lecture AQUOS non confirmée.");
        return discover(ip,port,report,false);
    }
    public static void inventory(String ip,Report report) throws Exception {
        host(ip);
        discover(ip,0,report,true);
    }
    private static Target discover(String ip,int port,Report report,boolean inventory) throws Exception {
        report.line("Recherche des services UPnP…");
        Set<String> locations=new LinkedHashSet<>();
        try(DatagramSocket s=new DatagramSocket()){
            s.setSoTimeout(400);
            String msg="M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nMAN: \"ssdp:discover\"\r\nMX: 1\r\nST: ssdp:all\r\n\r\n";
            byte[] data=msg.getBytes(StandardCharsets.US_ASCII);
            for(String address:new String[]{ip,"239.255.255.250"})s.send(new DatagramPacket(data,data.length,InetAddress.getByName(address),1900));
            long until=System.nanoTime()+2300000000L;byte[] packet=new byte[8192];
            while(System.nanoTime()<until && locations.size()<4){
                DatagramPacket reply=new DatagramPacket(packet,packet.length);
                try{s.receive(reply);}catch(SocketTimeoutException again){continue;}
                if(!reply.getAddress().getHostAddress().equals(ip))continue;
                for(String line:new String(packet,0,reply.getLength(),StandardCharsets.US_ASCII).split("\r?\n"))
                    if(line.regionMatches(true,0,"location:",0,9))locations.add(line.substring(9).trim());
            }
        }
        report.line(locations.isEmpty()?"Aucune description UPnP reçue.":"Réponse UPnP reçue de "+ip+".");
        for(String location:locations){
            try{
                URL desc=localURL(ip,null,location);Element doc=xml(desc,null,null).getDocumentElement();
                String name=field(doc,"friendlyName"); if(!name.isEmpty())report.line("Appareil annoncé · "+name);
                String ub=field(doc,"URLBase");URL base=ub.isEmpty()?desc:localURL(ip,desc,ub);
                NodeList services=doc.getElementsByTagNameNS("*","service");
                for(int i=0;i<services.getLength();i++){
                    Element service=(Element)services.item(i);String type=field(service,"serviceType");
                    report.line("Service annoncé · "+type);
                    if(inventory){
                        if(type.startsWith("urn:schemas-awox-com:service:X_ServiceManager:")){
                            try{describeActions(ip,base,service,report);}
                            catch(Exception e){report.line("Description AwoX indisponible · "+e.getMessage());}
                        }
                        continue;
                    }
                    if(!type.matches("urn:schemas-upnp-org:service:RenderingControl:[0-9]+"))continue;
                    Target upnp=new Target(ip,port,localURL(ip,base,field(service,"controlURL")).toString(),type);
                    read(upnp);return upnp;
                }
            }catch(Exception e){report.line("Description ou lecture UPnP indisponible · "+e.getMessage());}
        }
        if(inventory)return null;
        throw new IOException("Aucun volume accessible sur cette IP via AQUOS ou UPnP. Vérifie l’adresse de la Sharp et son accès réseau.");
    }
}
