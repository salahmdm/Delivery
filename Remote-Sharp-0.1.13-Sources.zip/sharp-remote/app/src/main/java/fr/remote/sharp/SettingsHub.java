package fr.remote.sharp;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.view.*;
import android.widget.*;
import static fr.remote.sharp.Studio.*;

public final class SettingsHub extends Activity {
    LinearLayout root;
    final String[] devices={"Apple TV","Téléviseur Sharp"};
    @Override public void onCreate(Bundle saved){super.onCreate(saved);window(this);}
    @Override public void onResume(){super.onResume();render();}
    void section(String title){
        TextView label=text(this,title,16,MINT,true);label.setPadding(0,dp(this,22),0,dp(this,2));add(root,label);
    }
    void row(String title,String detail,Runnable open){
        LinearLayout box=new LinearLayout(this);box.setOrientation(0);box.setGravity(Gravity.CENTER_VERTICAL);box.setBackground(shape(this,CARD,16));
        int p=dp(this,18);box.setPadding(p,p,p,p);
        LinearLayout copy=new LinearLayout(this);copy.setOrientation(1);copy.addView(text(this,title,20,FG,true));TextView sub=text(this,detail,14,DIM,false);
        sub.setPadding(0,dp(this,4),0,0);copy.addView(sub);box.addView(copy,new LinearLayout.LayoutParams(0,-2,1));
        box.addView(text(this,"›",26,MINT,false));box.setFocusable(true);box.setOnClickListener(v->open.run());add(root,box);
    }
    void render(){
        ScrollView scroll=new ScrollView(this);scroll.setBackgroundColor(BG);root=new LinearLayout(this);root.setOrientation(1);
        int p=dp(this,22);root.setPadding(p,dp(this,42),p,dp(this,46));scroll.addView(root);setContentView(scroll);
        root.addView(text(this,"Réglages",34,FG,true));row("Diagnostic Sharp","Afficher les services de la télévision",()->startActivity(new Intent(this,ReportActivity.class)));section("Appareils");
        row(devices[0],"Appairage, navigation et commandes",()->VolumeRoute.apple(this));
        row(devices[1],VolumeRoute.prefs.getString("draftIP","192.168.1.14")+"  ·  Connexion et essai sonore",()->startActivity(new Intent(this,SharpSettings.class)));
        section("Destination des touches de volume");
        LinearLayout segment=new LinearLayout(this);segment.setPadding(dp(this,4),dp(this,4),dp(this,4),dp(this,4));segment.setBackground(shape(this,CARD,16));add(root,segment);
        boolean direct=VolumeRoute.prefs.getBoolean("direct",false);
        for(int i=0;i<2;i++){final boolean sharp=i==1;boolean selected=direct==sharp;Button b=button(this,devices[i]);
            b.setSelected(selected);b.setTextColor(selected?BG:FG);b.setBackground(shape(this,selected?MINT:CARD,12));b.setContentDescription(devices[i]+(selected?", sélectionné":""));
            b.setOnClickListener(v->{VolumeRoute.prefs.edit().putBoolean("direct",sharp).apply();render();});segment.addView(b,new LinearLayout.LayoutParams(0,-2,1));}
        add(root,text(this,"Volume + et − pilotent "+(direct?"la Sharp en Wi-Fi.":"l’Apple TV."),15,DIM,false));
        String heard=VolumeRoute.prefs.getString("hearing","");
        if(!heard.isEmpty()){section("Dernier essai des haut-parleurs");add(root,text(this,heard,16,FG,false));}
        Button close=button(this,"Revenir à la télécommande");close.setOnClickListener(v->finish());add(root,close);
    }
}
