package fr.remote.sharp;

import android.app.Activity;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.*;
import static fr.remote.sharp.Studio.*;

public final class ReportActivity extends Activity {
    private TextView result;
    private Button copy;
    private static final String permission="android.permission.ACCESS_LOCAL_NETWORK";
    @Override public void onCreate(Bundle saved){
        super.onCreate(saved);window(this);
        LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setBackgroundColor(BG);
        int p=dp(this,20);root.setPadding(p,dp(this,48),p,p);
        root.addView(text(this,"Diagnostic Sharp",28,FG,true));
        copy=button(this,"Copier le résultat");add(root,copy);copy.setEnabled(false);
        ScrollView scroll=new ScrollView(this);add(root,scroll);
        result=text(this,"",16,FG,false);result.setTextIsSelectable(true);scroll.addView(result);setContentView(root);
        copy.setOnClickListener(v->{getSystemService(ClipboardManager.class).setPrimaryClip(ClipData.newPlainText("Diagnostic Sharp",result.getText()));Toast.makeText(this,"Résultat copié",Toast.LENGTH_SHORT).show();});
        if(android.os.Build.VERSION.SDK_INT>=37 && checkSelfPermission(permission)!=PackageManager.PERMISSION_GRANTED){result.setText("Autorise l’accès au réseau local pour lancer la lecture.");requestPermissions(new String[]{permission},1);}
        else runReport();
    }
    @Override public void onRequestPermissionsResult(int code,String[] perms,int[] results){
        super.onRequestPermissionsResult(code,perms,results);
        if(code==1 && results.length>0 && results[0]==PackageManager.PERMISSION_GRANTED)runReport();
        else result.setText("Accès au réseau local refusé. Tu peux l’autoriser dans les paramètres Android de l’application.");
    }
    private void runReport(){
        String host=VolumeRoute.prefs.getString("draftIP","192.168.1.14");
        result.setText("Sharp · "+host);
        VolumeRoute.worker.execute(()->{
            try{SharpWire.inventory(host,this::line);line("Recherche terminée.");}
            catch(Exception e){line("Lecture interrompue · "+e.getMessage());}
            runOnUiThread(()->{if(!isDestroyed())copy.setEnabled(true);});
        });
    }
    private void line(String message){runOnUiThread(()->{if(!isDestroyed())result.append("\n"+message);});}
}
