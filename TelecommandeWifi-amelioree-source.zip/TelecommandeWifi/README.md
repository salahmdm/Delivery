# Télécommande Wi-Fi — version 0.2 (prototype amélioré)

Application Android native Kotlin, sans service cloud.

## Ce qui est réellement implémenté
- Découverte SSDP sur Wi-Fi, puis vérification de l'API Roku ECP (port 8060).
- Ajout manuel par IPv4, choix de protocole, test de connexion.
- Pilote Roku ECP : navigation, volume selon capacités, lecture, chaînes et pavé numérique.
- Pilote Kodi JSON-RPC : navigation, volume, commandes média limitées. Activer l'interface HTTP Kodi sur le port 8080, sans authentification pour ce prototype (à réserver à un réseau de confiance).
- Enregistrement local des appareils, sélection et suppression, retours d'erreur et vibration.

## Non implémenté
- Samsung, LG, Android TV, Apple TV, Sony, Sharp/VIDAA : pas d'appairage ni de contrôle. Ces entrées sont explicitement signalées comme « à venir ».
- mDNS, découverte Kodi, widget, pavé tactile, clavier réseau, Wake-on-LAN, gestion des pièces, authentification Kodi, stockage chiffré, IR/RF.
- Aucun test sur téléviseur réel n'a été réalisé ; compatibilité et performance non garanties.

## Compilation
Placer le dossier `TelecommandeWifi` à la racine d'un dépôt GitHub (avec `.github/workflows/build.yml`) et lancer **Actions → Build TelecommandeWifi APK**. Le workflow utilise Java 17, Android SDK 35 et Gradle 8.13. Le fichier `app-debug.apk` est fourni dans les Artifacts si la compilation réussit.

Le ZIP est un **projet source**, pas un APK. Le SDK Android n'est pas disponible dans l'environnement de génération : build non vérifié.

## Sécurité
Le pilote Kodi utilise HTTP non chiffré. Ne pas l'exposer sur Internet. Les adresses des appareils sont enregistrées localement, sans compte.
